# 小满食堂：后端接口 v1

这是离线单机游戏的本地逻辑层，不需要 HTTP 服务。Claude 负责前端，Codex 负责本文档和后端实现。

## 加载与初始化

使用经典脚本，允许 `file://` 直接打开：

```html
<script src="engine.js"></script>
<script src="session.js"></script>
<script src="art.js"></script>
<script src="game.js"></script>
```

```js
const session = KitchenSession.createSession();
const game = session.game;
// 如有 session.profile.summary，先显示保存的结算界面。
// 否则显示主菜单，点击开店后调用：
const result = session.startDay();
if (!result.ok) console.log(result.reason);
```

`createSession({storage, random})` 可注入 Storage 兼容对象和随机函数。省略 storage 使用浏览器 localStorage；传 null 为纯内存模式。无网络调用，无运行时依赖。

## 分工和边界

- 前端只读 `game.state`；所有游戏变化通过方法调用。
- 使用 session 的 `startDay/startPractice/nextDay` 启动，不直接调用 `game.start`。
- 钱包、升级、跨天、记录只通过 session 方法修改。
- 引擎不处理 DOM、按键事件、真实时钟、音频、窗口可见性或绘制；前端负责这些适配。
- `session.profile` 返回独立副本，可缓存渲染，不可通过修改副本保存状态。
- `game.state` 对象引用保持稳定；内部数组、feedback、stats 等可能被替换，不缓存其引用。

## Session API

除 `save/snapshot/getUpgradeOffer` 外，操作返回 `{ok:true,...}` 或 `{ok:false,reason:string}`。失败不扣钱、不推进日期、不重启游戏。前端将 reason 映射为中文提示。

| 方法或属性 | 行为 |
| --- | --- |
| `session.game` | 本节以下的引擎实例 |
| `session.profile` | 当前存档副本 |
| `session.storageAvailable` | 能否使用持久存储；写入失败后变为 false，内存游戏继续 |
| `session.startDay()` | 从菜单开始 profile.day 的 90 秒营业；有待处理结算或已通关则拒绝 |
| `session.startPractice()` | 当前已到达日期的练习；不限营业时间、订单不超时、无捣乱，不计入存档 |
| `session.settleDay()` | 仅正式营业 summary 时入账并保存；重复调用不重复发钱；返回 `{ok,alreadySettled,summary}` |
| `session.getUpgradeOffer(key)` | 返回升级报价；未知 key 返回 null |
| `session.buyUpgrade(key)` | 结算时购买；返回 `{ok:true,cost,offer}`；每类最多 3 级 |
| `session.nextDay()` | 结算后推进一天并立即开始营业；第三天后拒绝 |
| `session.leave()` | 退出至菜单，放弃尚未结算的营业收益；不清除已保存结算和钱包 |
| `session.restartCampaign()` | 非营业/暂停状态下重置日期、钱包、升级；保留历史记录与声音偏好，返回菜单 |
| `session.setSound(boolean)` | 保存声音偏好；音频播放由前端完成 |
| `session.save()` | 将当前 profile 写入唯一存档键；返回是否成功 |
| `session.snapshot()` | `{profile,game,storageAvailable}` 的独立副本，调试和测试使用 |

`startDay/startPractice/nextDay` 成功还返回 `state`，即 `game.state`。活跃或暂停的营业不允许通过重复点击按钮重开，必须先显式 leave。

常见 reason：`busy`（游戏仍在进行）、`unsettled-shift`（刚结束的营业先结算，或显式退出放弃收益）、`campaign-complete`（三天已完成）、`settlement-pending`（先处理已保存结算）、`not-finished`（还未到结算）、`practice`（练习不入账）、`unknown-upgrade`、`not-in-settlement`、`max-level`、`insufficient-coins`、`invalid-sound`。

## Profile 和结算

```js
{
  version: 1,
  day: 1, // 1..3
  wallet: 0, // 跨天可用余额；与 game.state.coins 不同
  upgrades: { stove: 0, patience: 0, charm: 0 }, // 每类 0..3
  bestScore: 0, // 历史单日最高分
  bestCombo: 0, // 历史最高连续成功出餐数
  totalServed: 0, // 历史正式营业出餐数；重开三天仍保留
  completed: false,
  sound: true,
  summary: null // 或下面的结算对象
}
```

结算对象：`{day,score,coins,served,missed,bestCombo,stars,stats:{perfect,burned,pests}}`。stars 依据当日 served：0 道为 0 星，1..4 道为 1 星，5..9 道为 2 星，10 道起为 3 星。钱包在 settleDay 时增加 coins。

刷新页面后保留已完成营业、结算购物和设置。营业中的进度不恢复；该天从头开始，未结算收益不入账。存档键固定为 `xiaoman-kitchen:v1`，不读取、不清除其他站点存储。无效 JSON/未知版本重置为可玩默认值；存储被禁用、配额不足或 file 协议限制时自动降级内存模式。

### 结算流程

```js
if (game.state.phase === 'summary') {
  const result = session.settleDay(); // 可多次调用，不会重复入账
  if (result.ok) renderSummary(result.summary, session.profile);
}
// 购买按钮：
const offer = session.getUpgradeOffer('stove');
// {key,name,description,level,maxed,nextCost,canBuy}
// maxed 时 nextCost 为 null。
// 按钮是否可用取 canBuy，最终仍检查 buyUpgrade 的结果。
session.buyUpgrade('stove');
// 次日按钮：
session.nextDay();
// 通关后重新三天：
session.restartCampaign();
session.startDay();
```

升级常量：`KitchenSession.UPGRADE_DEFS`。

| key | 名称 | 各级价格 | 效果 |
| --- | --- | --- | --- |
| stove | 铸铁小灶 | 40 / 70 / 110 | 火候扫动时长每级 +0.45 秒 |
| patience | 窗边好茶 | 30 / 55 / 90 | 订单初始耐心每级 +6 秒 |
| charm | 招财小猫 | 35 / 60 / 100 | 每道菜每级 +2 金币 |

## Game API

| 方法 | 行为 |
| --- | --- |
| `game.selectOrder(id)` | 按真实数字订单 id 选单。重选同单保留进度；切菜或待出餐时换单会重新准备；烹饪中禁止换单 |
| `game.input(direction)` | `up/down/left/right`，仅 chop 阶段生效 |
| `game.action()` | cook 阶段尝试出锅；ready 阶段出餐。select/chop 不推进 |
| `game.shoo()` | 驱赶当前动物，奖励一次 |
| `game.tick(seconds)` | 推进秒数；仅 playing 生效，忽略非有限值、0 和负数 |
| `game.pause()` / `game.resume()` | playing 与 paused 互换 |
| `game.quit()` | 引擎底层退出；前端使用 session.leave 以同步结算状态 |

`game.start({day,practice,upgrades})` 是引擎底层方法，session 内部调用。

### State

```js
{
  phase: 'menu', // menu | playing | paused | summary
  day: 1,
  practice: false,
  timeLeft: 90, // 练习保持 90；界面依据 practice 显示“∞”
  coins: 0, score: 0, served: 0, missed: 0,
  combo: 0, bestCombo: 0,
  orders: [], // {id:number,recipeId:string,patience:number,maxPatience:number}
  selectedId: null,
  step: 'select', // select | chop | cook | ready
  sequence: [], // direction 字符串数组
  progress: 0, // 已完成切菜数，0..sequence.length
  heat: 0, // 0..1，从左到右单向扫动
  grade: null, // null | good | perfect
  pest: null, // 或 {remaining:秒数, kind:'sparrow'|'tanuki'}
  feedback: {text:'欢迎来到小满食堂',tone:'info',id:0},
  stats: {perfect:0,burned:0,pests:0},
  upgrades: {stove:0,patience:0,charm:0}
}
```

耐心进度条使用 `patience / maxPatience`，永远读取实时订单。id 跨天递增，不是数组下标；1/2/3 快捷键先从当前 orders 取对应 id。选中订单过期会清除准备并回到 select，新单自动补齐至三张。

feedback.id 每条消息递增，只在变化时播报/弹字；tone 为 info/success/warning/error。前端 `aria-live` 不应逐帧重读同一条反馈。

### 火候和分数

- 完整火候扫动：`2.8 + stove * 0.45` 秒；heat 在 `[0.42,0.72]` 为成功，`[0.52,0.62]` 为完美，区间端点包含。
- 过早/过晚按键会提示，可继续当前锅；heat 到 1 会糊锅并重做当前菜。
- 出餐后回到 select，由玩家选择下一单。combo 是连续成功出餐数，不是切菜按键次数。
- 成功出餐金币：菜价 + 完美奖励 4 + `min(5,combo-1)` + `charm*2`。
- 成功出餐得分：完美 150 / 普通 100，再加 `min(10,combo-1)*15`。
- 误切 -5、错误控火 -8、糊锅 -15、超时 -25，最低 0 分，并中断连击。
- 捣乱出现间隔 12..20 秒，5 秒内驱赶奖励 2 金币/10 分，否则订单额外损失 8 秒耐心。

### 菜谱

`KitchenEngine.RECIPES` 为冻结数组，每项 `{id,name,price,sequence,color}`。

| id | 名称 | 菜价 | 切菜顺序 |
| --- | --- | --- | --- |
| onigiri | 梅子饭团 | 14 | up right down |
| omurice | 番茄蛋包饭 | 22 | left up right down |
| curry | 金黄咖喱饭 | 30 | up left down right up |

首日两道菜；第二、三日加入咖喱。每次开店三张订单，前两张固定饭团和蛋包饭，第三张随机。耐心为 `38 - (day-1)*4 + patienceUpgrade*6` 秒。练习保留当前已到达日期菜谱和升级。

## 前端时钟、输入和生命周期

```js
let last = performance.now();
function frame(now) {
  const elapsed = (now - last) / 1000;
  last = now;
  game.tick(elapsed);
  render(game.state);
  requestAnimationFrame(frame);
}
window.addEventListener('blur', () => game.pause());
document.addEventListener('visibilitychange', () => {
  if (document.hidden) game.pause();
  last = performance.now();
});
// 玩家点击继续：重置 last，再 game.resume()。
// keydown：忽略 event.repeat；拦截方向键和空格默认行为。
```

不要用 setInterval 独立推进另一套火候或订单计时。键盘/触摸使用相同方法。暂停冻结营业、火候、订单和动物。帮助弹层打开时暂停，关闭时是否继续取决于打开前状态。

## 已提供美术

- `assets/kitchen.png`：1536×1024 原创像素厨房背景，本地 PNG。
- `assets/art-prompt.md`：完整提示词和内置 imagegen 来源。
- `art.js`：可选 Canvas 动态素材，全局 `KitchenArt`。所有位置为左上角，time 为毫秒。
- `drawDish(ctx,id,x,y,size=64)`：三个菜谱，size 方形。
- `drawChef(ctx,x,y,scale=1,time=0,mood='idle')`：100×140 缩放。
- `drawPest(ctx,x,y,scale=1,time=0,kind='bird')`：70×70 缩放；支持 bird/sparrow，其余显示小鼠，可自行替换 tanuki 表现。
- `drawBoard(ctx,x,y,width,height,progress=0)` 与 `drawPan(ctx,x,y,size=160,heat=0,recipeId='omurice',time=0)`。

## 后端检查

```powershell
node --test tests/engine.test.cjs tests/session.test.cjs
node --check engine.js
node --check session.js
```

浏览器视觉、键盘/触摸端到端实测由 Claude 的前端交付完成后进行。Node VM 验证经典脚本导出及 localStorage 禁用降级；不能替代真实浏览器交互验证。
