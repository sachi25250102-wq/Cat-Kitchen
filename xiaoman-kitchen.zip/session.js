(function (root, factory) {
  'use strict';
  const engine = typeof module === 'object' && module.exports ? require('./engine.js') : root.KitchenEngine;
  const api = factory(engine, root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.KitchenSession = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (engine, root) {
  'use strict';

  const STORAGE_KEY = 'xiaoman-kitchen:v1';
  const MAX_RECORD = 10000000;
  const UPGRADE_DEFS = Object.freeze({
    stove: Object.freeze({ name: '铸铁小灶', description: '火候指针变慢，更容易把握出锅时机。', costs: Object.freeze([40, 70, 110]) }),
    patience: Object.freeze({ name: '窗边好茶', description: '每级为客人增加 6 秒等待时间。', costs: Object.freeze([30, 55, 90]) }),
    charm: Object.freeze({ name: '招财小猫', description: '每级让每道料理多赚 2 金币。', costs: Object.freeze([35, 60, 100]) })
  });

  function integer(value, max = MAX_RECORD) {
    return Number.isFinite(value) ? Math.max(0, Math.min(max, Math.floor(value))) : 0;
  }

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function defaults() {
    return {
      version: 1, day: 1, wallet: 0, upgrades: { stove: 0, patience: 0, charm: 0 },
      bestScore: 0, bestCombo: 0, totalServed: 0, completed: false, sound: true, summary: null
    };
  }

  function summaryFor(value, day) {
    if (!value || typeof value !== 'object' || Array.isArray(value) || value.day !== day || !Number.isFinite(value.score) || !Number.isFinite(value.coins) || !Number.isFinite(value.served)) return null;
    const stats = value.stats && typeof value.stats === 'object' ? value.stats : {};
    const served = integer(value.served);
    return {
      day, score: integer(value.score), coins: integer(value.coins), served,
      missed: integer(value.missed), bestCombo: integer(value.bestCombo),
      stars: served >= 10 ? 3 : served >= 5 ? 2 : served > 0 ? 1 : 0,
      stats: { perfect: integer(stats.perfect), burned: integer(stats.burned), pests: integer(stats.pests) }
    };
  }

  function normalize(value) {
    const profile = defaults();
    if (!value || typeof value !== 'object' || Array.isArray(value) || value.version !== 1) return profile;
    profile.day = Math.max(1, integer(value.day, 3));
    for (const key of ['wallet', 'bestScore', 'bestCombo', 'totalServed']) profile[key] = integer(value[key]);
    const upgrades = value.upgrades && typeof value.upgrades === 'object' ? value.upgrades : {};
    for (const key of Object.keys(UPGRADE_DEFS)) profile.upgrades[key] = integer(upgrades[key], 3);
    profile.sound = typeof value.sound === 'boolean' ? value.sound : true;
    profile.summary = summaryFor(value.summary, profile.day);
    // Completion is derived from a settled third day, never an untrusted flag alone.
    profile.completed = profile.day === 3 && profile.summary !== null;
    return profile;
  }

  function createSession(options = {}) {
    const game = engine.createGame({ random: options.random });
    let storage = null;
    let storageAvailable = false;
    let profile = defaults();
    let activeCampaignShift = false;
    try {
      storage = Object.prototype.hasOwnProperty.call(options, 'storage') ? options.storage : root.localStorage;
      storageAvailable = Boolean(storage && typeof storage.getItem === 'function' && typeof storage.setItem === 'function');
      if (storageAvailable) {
        const saved = storage.getItem(STORAGE_KEY);
        if (saved) {
          try { profile = normalize(JSON.parse(saved)); } catch (_error) { profile = defaults(); }
        }
      }
    } catch (_error) {
      storageAvailable = false;
    }

    function save() {
      if (!storageAvailable) return false;
      try {
        storage.setItem(STORAGE_KEY, JSON.stringify(profile));
        return true;
      } catch (_error) {
        storageAvailable = false;
        return false;
      }
    }

    function busy() {
      return game.state.phase === 'playing' || game.state.phase === 'paused';
    }

    function fail(reason) {
      return { ok: false, reason };
    }

    function startDay() {
      if (busy()) return fail('busy');
      if (activeCampaignShift && game.state.phase === 'summary') return fail('unsettled-shift');
      if (profile.completed) return fail('campaign-complete');
      if (profile.summary) return fail('settlement-pending');
      activeCampaignShift = true;
      game.start({ day: profile.day, upgrades: profile.upgrades });
      return { ok: true, state: game.state };
    }

    function startPractice() {
      if (busy()) return fail('busy');
      if (activeCampaignShift && game.state.phase === 'summary') return fail('unsettled-shift');
      activeCampaignShift = false;
      game.start({ day: profile.day, practice: true, upgrades: profile.upgrades });
      return { ok: true, state: game.state };
    }

    function settleDay() {
      if (game.state.practice && busy()) return fail('practice');
      if (profile.summary) return { ok: true, alreadySettled: true, summary: clone(profile.summary) };
      if (!activeCampaignShift || game.state.phase !== 'summary' || game.state.practice) return fail('not-finished');
      const summary = summaryFor(game.state, profile.day);
      profile.wallet = integer(profile.wallet + summary.coins);
      profile.bestScore = Math.max(profile.bestScore, summary.score);
      profile.bestCombo = Math.max(profile.bestCombo, summary.bestCombo);
      profile.totalServed = integer(profile.totalServed + summary.served);
      profile.summary = summary;
      profile.completed = profile.day === 3;
      activeCampaignShift = false;
      save();
      return { ok: true, alreadySettled: false, summary: clone(summary) };
    }

    function canShop() {
      return Boolean(profile.summary && !busy());
    }

    function getUpgradeOffer(key) {
      if (typeof key !== 'string' || !Object.prototype.hasOwnProperty.call(UPGRADE_DEFS, key)) return null;
      const definition = UPGRADE_DEFS[key];
      const level = profile.upgrades[key];
      const maxed = level >= definition.costs.length;
      const nextCost = maxed ? null : definition.costs[level];
      return {
        key, name: definition.name, description: definition.description, level, maxed, nextCost,
        canBuy: canShop() && !maxed && profile.wallet >= nextCost
      };
    }

    function buyUpgrade(key) {
      const offer = getUpgradeOffer(key);
      if (!offer) return fail('unknown-upgrade');
      if (!canShop()) return fail('not-in-settlement');
      if (offer.maxed) return fail('max-level');
      if (profile.wallet < offer.nextCost) return fail('insufficient-coins');
      profile.wallet -= offer.nextCost;
      profile.upgrades[key] += 1;
      save();
      return { ok: true, cost: offer.nextCost, offer: getUpgradeOffer(key) };
    }

    function nextDay() {
      if (busy()) return fail('busy');
      if (!profile.summary) return fail('not-in-settlement');
      if (profile.completed || profile.day >= 3) return fail('campaign-complete');
      profile.day += 1;
      profile.summary = null;
      save();
      return startDay();
    }

    function leave() {
      activeCampaignShift = false;
      game.quit();
      return { ok: true };
    }

    function restartCampaign() {
      if (busy()) return fail('busy');
      const previous = profile;
      profile = defaults();
      for (const key of ['bestScore', 'bestCombo', 'totalServed', 'sound']) profile[key] = previous[key];
      leave();
      save();
      return { ok: true };
    }

    function setSound(enabled) {
      if (typeof enabled !== 'boolean') return fail('invalid-sound');
      profile.sound = enabled;
      save();
      return { ok: true };
    }

    return {
      game, get profile() { return clone(profile); }, get storageAvailable() { return storageAvailable; },
      startDay, startPractice, settleDay, nextDay, leave, restartCampaign,
      getUpgradeOffer, buyUpgrade, setSound, save,
      snapshot() { return { profile: clone(profile), game: clone(game.state), storageAvailable }; }
    };
  }

  return { STORAGE_KEY, UPGRADE_DEFS, createSession };
});
