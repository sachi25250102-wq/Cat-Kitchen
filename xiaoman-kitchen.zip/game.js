/* 小满食堂 —— 前端主控。
   负责：菜单与弹层、键盘/鼠标/触屏输入、帧循环、失焦暂停、结算与升级界面、音效触发。
   游戏规则全部在 engine.js / session.js 里：这里只读 game.state，所有变化都走 session 和 game 的方法。 */
(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);

  if (!window.KitchenEngine || !window.KitchenSession || !window.KitchenStage) {
    const fatal = document.createElement('p');
    fatal.className = 'fatal';
    fatal.textContent = '游戏文件没有加载完整。请确认 index.html 和 engine.js、session.js、stage.js、game.js 放在同一个文件夹里，然后刷新页面。';
    document.body.appendChild(fatal);
    return;
  }

  const session = window.KitchenSession.createSession();
  const game = session.game;
  const state = game.state; // 只读；引用稳定，内部数组和对象可能被替换，所以每次都重新读取
  const RECIPES = {};
  window.KitchenEngine.RECIPES.forEach((recipe) => { RECIPES[recipe.id] = recipe; });
  const UPGRADE_KEYS = Object.keys(window.KitchenSession.UPGRADE_DEFS);
  const sfx = window.KitchenSfx || { unlock() {}, setEnabled() {}, play() {}, setSizzle() {} };
  const motionQuery = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
  const stage = window.KitchenStage.create($('stageCanvas'), { calm: Boolean(motionQuery && motionQuery.matches) });

  const el = {
    game: $('game'), play: $('play'), stage: $('stage'), title: $('titleScreen'),
    titleTags: $('titleTags'), ledger: $('ledger'),
    hudDay: $('hudDay'), hudTime: $('hudTime'), hudTimeWrap: $('hudTimeWrap'), hudTimeUnit: $('hudTimeUnit'),
    hudCoins: $('hudCoins'), hudScore: $('hudScore'), hudCombo: $('hudCombo'), hudComboWrap: $('hudComboWrap'),
    btnPause: $('btnPause'), btnHelpHud: $('btnHelpHud'), btnSoundHud: $('btnSoundHud'), soundHudIcon: $('soundHudIcon'),
    cueChop: $('cueChop'), cueHeat: $('cueHeat'), heatNeedle: $('heatNeedle'),
    pestBtn: $('pestBtn'), pestFill: $('pestFill'), floats: $('floats'), banner: $('banner'), bannerText: $('bannerText'),
    tickets: $('tickets'), feedback: $('feedback'), pad: $('pad'), actionLabel: $('actionLabel'),
    titleArt: $('titleArt'), btnStart: $('btnStart'), startText: $('startText'), startNote: $('startNote'),
    btnPractice: $('btnPractice'), btnHelp: $('btnHelp'), btnSound: $('btnSound'), soundNote: $('soundNote'), btnReset: $('btnReset'),
    recScore: $('recScore'), recCombo: $('recCombo'), recServed: $('recServed'), recWallet: $('recWallet'), storageNote: $('storageNote'),
    veil: $('veil'), pauseSheet: $('pauseSheet'), helpSheet: $('helpSheet'), billSheet: $('billSheet'), confirmSheet: $('confirmSheet'),
    pauseNote: $('pauseNote'), btnResume: $('btnResume'), resumeText: $('resumeText'), btnRestartShift: $('btnRestartShift'),
    restartNote: $('restartNote'), btnHelpPause: $('btnHelpPause'), btnSoundPause: $('btnSoundPause'), soundNotePause: $('soundNotePause'),
    btnLeave: $('btnLeave'), leaveText: $('leaveText'), leaveNote: $('leaveNote'), btnHelpClose: $('btnHelpClose'),
    tallyServed: $('tallyServed'), tallyStars: $('tallyStars'), tallyNext: $('tallyNext'),
    billTitle: $('billTitle'), billStars: $('billStars'), billHint: $('billHint'), billLines: $('billLines'),
    billIncome: $('billIncome'), billWallet: $('billWallet'), shop: $('shop'), shopList: $('shopList'),
    finale: $('finale'), finaleLines: $('finaleLines'), billStorageNote: $('billStorageNote'),
    btnNextDay: $('btnNextDay'), btnBillRestart: $('btnBillRestart'), btnBillTitle: $('btnBillTitle'),
    confirmText: $('confirmText'), btnConfirmOk: $('btnConfirmOk'), btnConfirmCancel: $('btnConfirmCancel'),
    toast: $('toast')
  };

  const SHEETS = { pause: el.pauseSheet, help: el.helpSheet, bill: el.billSheet, confirm: el.confirmSheet };
  const CN_DIGIT = ['零', '一', '二', '三'];
  const PAUSE_NOTE = '营业时间、火候和订单都停住了。';
  const AWAY_NOTE = '窗口切走了，已自动暂停。准备好了再继续。';

  // session 返回的 reason → 给玩家看的话
  const REASONS = {
    'busy': '营业还在进行。先暂停，再选择重新开始或回到菜单。',
    'unsettled-shift': '刚结束的营业还没结算，先看结算。',
    'campaign-complete': '三天营业已经全部完成，可以重新开始三天。',
    'settlement-pending': '上一天的结算还没处理，先看结算。',
    'not-finished': '营业还没结束，现在不能结算。',
    'practice': '练习模式不记收入。',
    'unknown-upgrade': '没有这项升级。',
    'not-in-settlement': '打烊结算时才能添置升级。',
    'max-level': '这项升级已经满级。',
    'insufficient-coins': '金币不够，再营业一天攒一攒。',
    'invalid-sound': '声音设置没有保存成功。'
  };

  // 飘字位置：舞台宽高的百分比，对应 stage.js 里的摆位
  const SPOT = {
    board: [20.8, 61], pan: [65, 58], tray: [82, 63], pest: [38.7, 64], chef: [55, 26], orders: [88, 30]
  };

  const CODE_TOKENS = {
    ArrowUp: 'up', KeyW: 'up', ArrowDown: 'down', KeyS: 'down',
    ArrowLeft: 'left', KeyA: 'left', ArrowRight: 'right', KeyD: 'right',
    Space: 'action', KeyF: 'shoo', Escape: 'pause', KeyP: 'pause', KeyH: 'help', KeyM: 'sound',
    Digit1: 'order0', Numpad1: 'order0', Digit2: 'order1', Numpad2: 'order1', Digit3: 'order2', Numpad3: 'order2'
  };
  // 没有 code 的按键事件（部分虚拟键盘、脚本派发）按 key 兜底
  const KEY_TOKENS = {
    ArrowUp: 'up', w: 'up', ArrowDown: 'down', s: 'down', ArrowLeft: 'left', a: 'left', ArrowRight: 'right', d: 'right',
    ' ': 'action', Spacebar: 'action', f: 'shoo', Escape: 'pause', Esc: 'pause', p: 'pause', h: 'help', '?': 'help', m: 'sound',
    '1': 'order0', '2': 'order1', '3': 'order2'
  };
  const DIRECTIONS = { up: true, down: true, left: true, right: true };

  const ui = {
    screen: 'title',     // title | play
    sheets: [],          // 弹层栈，最后一个显示在最上面
    last: performance.now(),
    resumeAfterHelp: false,
    ending: false,
    confirm: null,
    billSummary: null,
    lowTick: -1,
    shown: {},
    titleLayout: null,
    billTimer: 0,
    toastTimer: 0,
    bannerTimer: 0
  };
  const ticketEls = new Map();
  let tiles = [];
  let prev = snapshot();

  /* ---------- 小工具 ---------- */

  function snapshot() {
    return { burned: state.stats.burned, missed: state.missed, pests: state.stats.pests, pest: Boolean(state.pest) };
  }

  function setText(node, value, key) {
    if (ui.shown[key] === value) return;
    ui.shown[key] = value;
    node.textContent = value;
  }

  function setData(name, value) {
    if (el.game.dataset[name] !== value) el.game.dataset[name] = value;
  }

  function restartAnimation(node, className) {
    node.classList.remove(className);
    void node.offsetWidth; // 强制回流，让同一个动画可以重播
    node.classList.add(className);
  }

  function blurActive() {
    const active = document.activeElement;
    if (active && active !== document.body && typeof active.blur === 'function') active.blur();
  }

  function selectedRecipeId() {
    const order = state.orders.find((ticket) => ticket.id === state.selectedId);
    return order ? order.recipeId : null;
  }

  function toast(text) {
    el.toast.textContent = text;
    el.toast.hidden = false;
    clearTimeout(ui.toastTimer);
    ui.toastTimer = setTimeout(() => { el.toast.hidden = true; }, 2800);
  }

  function toastReason(reason) {
    toast(REASONS[reason] || '这一步没有成功，请再试一次。');
    sfx.play('deny');
  }

  function showBanner(text) {
    el.bannerText.textContent = text;
    restartAnimation(el.banner, 'is-on');
    clearTimeout(ui.bannerTimer);
    ui.bannerTimer = setTimeout(() => el.banner.classList.remove('is-on'), 1600);
  }

  function float(text, spot, tone) {
    const node = document.createElement('span');
    node.className = 'float';
    node.dataset.tone = tone || '';
    node.textContent = text;
    node.style.left = (spot[0] + (Math.random() - 0.5) * 3).toFixed(1) + '%';
    node.style.top = spot[1] + '%';
    el.floats.appendChild(node);
    node.addEventListener('animationend', () => node.remove());
    setTimeout(() => node.remove(), 1500);
    while (el.floats.childElementCount > 8) el.floats.firstElementChild.remove();
  }

  function flashKey(token) {
    const selector = DIRECTIONS[token] ? '[data-dir="' + token + '"]' : '[data-act="' + token + '"]';
    const key = el.pad.querySelector(selector);
    if (!key) return;
    key.classList.add('is-down');
    setTimeout(() => key.classList.remove('is-down'), 110);
  }

  /* ---------- 画面与弹层 ---------- */

  function applyInert() {
    const covered = ui.sheets.length > 0;
    el.play.inert = covered || ui.screen !== 'play';
    el.title.inert = covered || ui.screen !== 'title';
  }

  function setScreen(name) {
    ui.screen = name;
    el.game.dataset.screen = name;
    applyInert();
  }

  function topSheet() {
    return ui.sheets.length ? ui.sheets[ui.sheets.length - 1] : null;
  }

  function renderSheets(moveFocus) {
    const top = topSheet();
    Object.keys(SHEETS).forEach((name) => { SHEETS[name].hidden = name !== top; });
    el.veil.hidden = !top;
    applyInert();
    if (!top || moveFocus === false) return;
    // 日结单不默认聚焦任何按钮：打烊那一刻玩家多半还在连按空格，不能让它顺手点掉“开始下一天”。
    const sheet = SHEETS[top];
    (sheet.querySelector('[data-autofocus]:not([hidden])') || sheet).focus({ preventScroll: true });
    sheet.scrollTop = 0;
  }

  function pushSheet(name) {
    ui.sheets = ui.sheets.filter((item) => item !== name);
    ui.sheets.push(name);
    renderSheets();
  }

  function dropSheet(name) {
    ui.sheets = ui.sheets.filter((item) => item !== name);
    renderSheets();
    if (!ui.sheets.length && ui.screen === 'title') el.btnStart.focus({ preventScroll: true });
  }

  /* ---------- 标题画面 ---------- */

  function refreshSound(on) {
    [el.btnSound, el.btnSoundPause, el.btnSoundHud].forEach((button) => button.setAttribute('aria-pressed', String(on)));
    el.soundNote.textContent = on ? '已开启' : '已关闭';
    el.soundNotePause.textContent = on ? '已开启' : '已关闭';
    el.soundHudIcon.setAttribute('href', on ? '#i-sound-on' : '#i-sound-off');
    el.btnSoundHud.setAttribute('aria-label', on ? '声音，现在是开启' : '声音，现在是关闭');
  }

  function refreshTitle() {
    const profile = session.profile;
    if (profile.summary) {
      el.startText.textContent = '查看结算';
      el.startNote.textContent = profile.completed ? '三天圆满' : '第' + CN_DIGIT[profile.day] + '天';
    } else {
      el.startText.textContent = '开店营业';
      el.startNote.textContent = '第' + CN_DIGIT[profile.day] + '天';
    }
    const touched = profile.day > 1 || profile.wallet > 0 || Boolean(profile.summary) ||
      UPGRADE_KEYS.some((key) => profile.upgrades[key] > 0);
    el.btnReset.hidden = !touched;
    el.recScore.textContent = String(profile.bestScore);
    el.recCombo.textContent = String(profile.bestCombo);
    el.recServed.textContent = String(profile.totalServed);
    el.recWallet.textContent = String(profile.wallet);
    el.storageNote.hidden = session.storageAvailable;
    refreshSound(profile.sound);
    measure(); // 木札数量变了，猫厨师的站位跟着重算
  }

  function showTitle() {
    clearTimeout(ui.billTimer);
    ui.ending = false;
    ui.resumeAfterHelp = false;
    ui.sheets = [];
    setScreen('title');
    renderSheets(false);
    refreshTitle();
    sfx.setSizzle(0);
    el.btnStart.focus({ preventScroll: true });
  }

  // 招牌：把系统宋体画在小画布上再按阈值取点，放大后就是和厨房同一风格的像素字。
  function drawTitleArt() {
    const canvas = el.titleArt;
    const ctx = canvas.getContext ? canvas.getContext('2d') : null;
    if (!ctx) { canvas.hidden = true; return; }
    try {
      const w = canvas.width;
      const h = canvas.height;
      const scratch = document.createElement('canvas');
      scratch.width = w;
      scratch.height = h;
      const pen = scratch.getContext('2d', { willReadFrequently: true });
      const family = getComputedStyle(document.documentElement).getPropertyValue('--font-title').trim() || 'serif';
      pen.font = '900 28px ' + family;
      pen.textAlign = 'center';
      pen.textBaseline = 'middle';
      pen.fillStyle = '#000';
      const chars = ['小', '满', '食', '堂'];
      const cell = (w - 4) / chars.length;
      chars.forEach((char, index) => pen.fillText(char, 2 + cell * (index + 0.5), h / 2 + 1));
      const source = pen.getImageData(0, 0, w, h).data;
      const mask = new Uint8Array(w * h);
      let lit = 0;
      for (let i = 0; i < mask.length; i++) {
        if (source[i * 4 + 3] > 96) { mask[i] = 1; lit += 1; }
      }
      if (lit < 60) { canvas.hidden = true; return; } // 没有可用的中文字体
      const image = ctx.createImageData(w, h);
      const put = (x, y, r, g, b) => {
        if (x < 0 || y < 0 || x >= w || y >= h) return;
        const at = (y * w + x) * 4;
        image.data[at] = r; image.data[at + 1] = g; image.data[at + 2] = b; image.data[at + 3] = 255;
      };
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) if (mask[y * w + x]) put(x + 1, y + 1, 152, 57, 45);
      }
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) if (mask[y * w + x]) put(x, y, 255, 241, 210);
      }
      ctx.putImageData(image, 0, 0);
    } catch (_error) {
      canvas.hidden = true;
    }
  }

  /* ---------- 开店、练习、离开 ---------- */

  function begin(result) {
    if (result.ok) { enterPlay(); return true; }
    toastReason(result.reason);
    if (result.reason === 'settlement-pending') {
      const summary = session.profile.summary;
      if (summary) openBill(summary);
    } else if (result.reason === 'unsettled-shift') {
      const settled = session.settleDay();
      if (settled.ok) openBill(settled.summary);
    } else if (ui.screen === 'title') refreshTitle();
    return false;
  }

  function enterPlay() {
    clearTimeout(ui.billTimer);
    ui.ending = false;
    ui.resumeAfterHelp = false;
    ui.sheets = [];
    setScreen('play');
    renderSheets(false);
    blurActive();
    stage.emit('reset');
    ticketEls.forEach((ticket) => ticket.li.remove());
    ticketEls.clear();
    ui.shown = {};
    ui.lowTick = -1;
    prev = snapshot();
    ui.last = performance.now();
    measure();
    renderDom();
    showBanner(state.practice ? '练习开始' : '第 ' + state.day + ' 天 开店');
    sfx.play('dayStart');
  }

  function onStart() {
    const summary = session.profile.summary;
    if (summary) { openBill(summary); return; }
    begin(session.startDay());
  }

  function restartShift() {
    const practice = state.practice;
    session.leave();
    begin(practice ? session.startPractice() : session.startDay());
  }

  function leaveShift() {
    session.leave();
    showTitle();
  }

  /* ---------- 暂停与帮助 ---------- */

  function setPauseTexts(note) {
    const practice = state.practice;
    el.pauseNote.textContent = note || PAUSE_NOTE;
    el.resumeText.textContent = practice ? '继续练习' : '继续营业';
    el.restartNote.textContent = practice ? '练习重来' : '今天重来';
    el.leaveText.textContent = practice ? '结束练习' : '回到菜单';
    el.leaveNote.textContent = practice ? '回到菜单' : '放弃今天';
  }

  // 暂停和恢复都重置帧时间戳，暂停期间不会攒下时间。
  function pauseGame() {
    if (ui.screen !== 'play' || state.phase !== 'playing') return false;
    advance(performance.now());
    if (state.phase !== 'playing') return false;
    game.pause();
    ui.last = performance.now();
    sfx.setSizzle(0);
    return true;
  }

  function openPause(note) {
    if (!pauseGame()) return;
    ui.resumeAfterHelp = false;
    setPauseTexts(note);
    ui.sheets = ['pause'];
    renderSheets();
  }

  function resumeGame() {
    if (state.phase !== 'paused') return;
    ui.sheets = [];
    renderSheets(false);
    blurActive();
    ui.last = performance.now();
    game.resume();
    prev = snapshot();
  }

  function openHelp() {
    if (topSheet() === 'help') return;
    if (pauseGame()) ui.resumeAfterHelp = true; // 打开前正在营业：关闭帮助后直接继续
    pushSheet('help');
  }

  function closeHelp() {
    const resume = ui.resumeAfterHelp && ui.sheets.length === 1 && state.phase === 'paused';
    ui.resumeAfterHelp = false;
    if (resume) { resumeGame(); return; }
    dropSheet('help');
  }

  // 失焦或切出页面：营业中就暂停，回来后由玩家自己点继续。
  function onAway() {
    if (ui.screen !== 'play') return;
    if (state.phase === 'playing') {
      openPause(AWAY_NOTE);
    } else if (state.phase === 'paused' && ui.resumeAfterHelp) {
      ui.resumeAfterHelp = false;
      setPauseTexts(AWAY_NOTE);
      ui.sheets = ['pause', 'help'];
      renderSheets(false);
    }
  }

  function askConfirm(text, okLabel, action) {
    ui.confirm = action;
    el.confirmText.textContent = text;
    el.btnConfirmOk.textContent = okLabel;
    pushSheet('confirm');
  }

  function answerConfirm(accepted) {
    const action = ui.confirm;
    ui.confirm = null;
    dropSheet('confirm');
    if (accepted && action) action();
  }

  function dismissTop() {
    const top = topSheet();
    if (top === 'pause') resumeGame();
    else if (top === 'help') closeHelp();
    else if (top === 'confirm') answerConfirm(false);
  }

  function toggleSound() {
    const next = !session.profile.sound;
    const result = session.setSound(next);
    if (!result.ok) { toastReason(result.reason); return; }
    sfx.setEnabled(next);
    refreshSound(next);
    if (next) sfx.play('click');
    el.storageNote.hidden = session.storageAvailable;
    if (ui.screen === 'play' && !ui.sheets.length) blurActive(); // 焦点不留在 HUD 按钮上，回车不会误触
  }

  /* ---------- 结算与升级 ---------- */

  function fillLines(list, rows) {
    list.textContent = '';
    rows.forEach((row) => {
      const line = document.createElement('div');
      const label = document.createElement('dt');
      const value = document.createElement('dd');
      label.textContent = row[0];
      value.textContent = row[1];
      line.append(label, value);
      list.appendChild(line);
    });
  }

  function renderShop(wallet) {
    el.shopList.textContent = '';
    UPGRADE_KEYS.forEach((key) => {
      const offer = session.getUpgradeOffer(key);
      if (!offer) return;
      const item = document.createElement('li');
      item.className = 'shop-item';

      const info = document.createElement('div');
      info.className = 'shop-info';
      const name = document.createElement('h4');
      name.textContent = offer.name;
      const pips = document.createElement('span');
      pips.className = 'pips';
      pips.setAttribute('role', 'img');
      pips.setAttribute('aria-label', '等级 ' + offer.level + '，最高 3');
      for (let i = 0; i < 3; i++) {
        const pip = document.createElement('i');
        if (i < offer.level) pip.className = 'is-on';
        pips.appendChild(pip);
      }
      name.appendChild(pips);
      const description = document.createElement('p');
      description.textContent = offer.description + (offer.maxed ? '' : ' 下一级 ' + offer.nextCost + ' 金币。');
      info.append(name, description);

      const buy = document.createElement('button');
      buy.type = 'button';
      buy.className = 'btn btn-buy';
      buy.dataset.key = key;
      buy.disabled = !offer.canBuy;
      if (offer.maxed) buy.textContent = '已满级';
      else if (offer.canBuy) buy.textContent = '购买 ' + offer.nextCost + ' 金币';
      else buy.textContent = '还差 ' + Math.max(0, offer.nextCost - wallet) + ' 金币';
      buy.setAttribute('aria-label', offer.name + '：' + buy.textContent);

      item.append(info, buy);
      el.shopList.appendChild(item);
    });
  }

  function renderBill() {
    const summary = ui.billSummary;
    const profile = session.profile;
    const done = profile.completed;

    el.billTitle.textContent = done ? '三天营业圆满结束' : '第 ' + summary.day + ' 天打烊';
    el.billStars.textContent = '';
    for (let i = 0; i < 3; i++) {
      const star = document.createElement('span');
      star.textContent = '★';
      if (i < summary.stars) star.className = 'is-on';
      el.billStars.appendChild(star);
    }
    el.billStars.setAttribute('aria-label', '今日评价 ' + summary.stars + ' 星，满分 3 星');
    el.billHint.textContent = summary.stars >= 3 ? '出餐满 10 道，三星到手。'
      : summary.served >= 5 ? '出餐满 10 道就是三星，今天还差 ' + (10 - summary.served) + ' 道。'
        : '出餐满 5 道两星，满 10 道三星。';

    fillLines(el.billLines, [
      ['出餐', summary.served + ' 道'],
      ['客人离开', summary.missed + ' 位'],
      ['得分', String(summary.score)],
      ['最高连击', String(summary.bestCombo)],
      ['完美火候', summary.stats.perfect + ' 次'],
      ['糊锅', summary.stats.burned + ' 次'],
      ['赶走小馋鬼', summary.stats.pests + ' 次']
    ]);
    el.billIncome.textContent = '+' + summary.coins + ' 金币';
    el.billWallet.textContent = profile.wallet + ' 金币';

    el.shop.hidden = done;
    el.finale.hidden = !done;
    if (done) {
      fillLines(el.finaleLines, [
        ['历史最高分', String(profile.bestScore)],
        ['历史最高连击', String(profile.bestCombo)],
        ['累计出餐', profile.totalServed + ' 道'],
        ['剩余金币', String(profile.wallet)]
      ]);
    } else renderShop(profile.wallet);

    el.btnNextDay.hidden = done;
    el.btnNextDay.textContent = '开始第 ' + (summary.day + 1) + ' 天';
    el.btnBillRestart.hidden = !done;
    el.btnBillRestart.classList.toggle('btn-main', done);
    el.billStorageNote.hidden = session.storageAvailable;
  }

  function openBill(summary) {
    clearTimeout(ui.billTimer);
    ui.billSummary = summary;
    renderBill();
    ui.sheets = ['bill'];
    renderSheets();
  }

  function buyUpgrade(key) {
    const result = session.buyUpgrade(key);
    if (result.ok) {
      sfx.play('coin');
      toast(result.offer.name + '升到 ' + result.offer.level + ' 级。');
    } else toastReason(result.reason);
    renderBill();
    const again = el.shopList.querySelector('[data-key="' + key + '"]:not(:disabled)');
    (again || el.billSheet).focus({ preventScroll: true });
  }

  // 正式营业结束：先结算入账，再展示日结单。
  function endDay() {
    ui.ending = true;
    sfx.setSizzle(0);
    const result = session.settleDay();
    sfx.play('dayEnd');
    showBanner('打烊啦');
    ui.billTimer = setTimeout(() => {
      if (result.ok) { openBill(result.summary); return; }
      toastReason(result.reason);
      leaveShift();
    }, 1300);
  }

  /* ---------- 时钟 ---------- */

  // 单次推进最多 1 秒：页面被冻结或电脑休眠后回来，不会一口气吃掉整天的营业时间。
  function advance(now) {
    if (now <= ui.last) return;
    const seconds = Math.min(1, (now - ui.last) / 1000);
    ui.last = now;
    if (ui.screen !== 'play' || state.phase !== 'playing') return;
    game.tick(seconds);
    detect();
  }

  // 由时间推动的事件：糊锅、订单超时、小馋鬼出现或得手、打烊。
  // 每帧都对比一次真实状态，所以不管时间是谁推进的（包括联调时直接调 game.tick），界面都跟得上。
  function detect() {
    if (ui.screen !== 'play') return;
    if (state.stats.burned > prev.burned) {
      stage.emit('burn');
      sfx.play('burn');
      float('糊锅了', SPOT.pan, 'bad');
    }
    if (state.missed > prev.missed) {
      sfx.play('expire');
      float('客人走了', SPOT.orders, 'bad');
    }
    const pestNow = Boolean(state.pest);
    if (pestNow && !prev.pest) {
      stage.emit('pestIn', { kind: state.pest.kind });
      sfx.play('pestIn');
    } else if (!pestNow && prev.pest) {
      if (state.phase === 'playing') {
        stage.emit('pestSteal');
        sfx.play('steal');
        float('被偷吃了', SPOT.pest, 'bad');
      } else stage.emit('pestGone');
    }
    if (!state.practice && state.phase === 'playing' && state.timeLeft <= 10) {
      const second = Math.ceil(state.timeLeft);
      if (second !== ui.lowTick) { ui.lowTick = second; sfx.play('tick'); }
    }
    prev = snapshot();
    if (state.phase === 'summary' && !ui.ending) endDay();
  }

  /* ---------- 玩家操作：键盘、鼠标、触屏都走这四个入口 ---------- */

  function ready() {
    if (ui.screen !== 'play' || ui.sheets.length || state.phase !== 'playing') return false;
    advance(performance.now()); // 把时间推到按键这一刻，火候判定更准
    return state.phase === 'playing';
  }

  function doSelect(id) {
    if (!ready()) return;
    const before = state.selectedId;
    game.selectOrder(id);
    if (state.selectedId !== before) sfx.play('select');
    else if (id !== before) sfx.play('deny');
    prev = snapshot();
    renderDom();
  }

  function doInput(direction) {
    if (!ready()) return;
    flashKey(direction);
    if (state.step !== 'chop') return;
    const before = state.progress;
    game.input(direction);
    if (state.step === 'cook') {
      stage.emit('toPan');
      sfx.play('chop');
      sfx.play('toPan');
    } else if (state.progress > before) {
      stage.emit('chop');
      sfx.play('chop');
    } else {
      stage.emit('wrong');
      sfx.play('wrong');
      restartAnimation(el.cueChop, 'is-wrong');
      float('切错了', SPOT.board, 'bad');
    }
    prev = snapshot();
    renderDom();
  }

  function doAction() {
    if (!ready()) return;
    flashKey('action');
    const step = state.step;
    const heat = state.heat;
    const coins = state.coins;
    const served = state.served;
    const recipeId = selectedRecipeId();
    game.action();
    if (step === 'cook' && state.step === 'ready') {
      const perfect = state.grade === 'perfect';
      stage.emit(perfect ? 'perfect' : 'good');
      sfx.play(perfect ? 'perfect' : 'good');
      float(perfect ? '完美火候' : '火候不错', SPOT.pan, perfect ? 'gold' : 'good');
    } else if (step === 'cook') {
      stage.emit('miss');
      sfx.play('miss');
      restartAnimation(el.cueHeat, 'is-wrong');
      float(heat < 0.42 ? '还没熟' : '火大了', SPOT.pan, 'bad');
    } else if (step === 'ready' && state.served > served) {
      stage.emit('serve', { recipeId: recipeId });
      sfx.play('serve');
      float('+' + (state.coins - coins) + ' 金币', SPOT.tray, 'gold');
      if (state.combo >= 2) float('连击 ×' + state.combo, SPOT.chef, 'good');
    } else sfx.play('deny');
    prev = snapshot();
    renderDom();
  }

  function doShoo() {
    if (!ready()) return;
    flashKey('shoo');
    if (!state.pest) return;
    game.shoo();
    if (!state.pest) {
      stage.emit('pestShoo');
      sfx.play('shoo');
      float('+2 金币', SPOT.pest, 'gold');
    }
    prev = snapshot();
    renderDom();
  }

  function runToken(token) {
    if (DIRECTIONS[token]) doInput(token);
    else if (token === 'action') doAction();
    else if (token === 'shoo') doShoo();
    else if (token.indexOf('order') === 0) {
      const order = state.orders[Number(token.slice(5))]; // 1/2/3 先取当前第几张订单的真实 id
      if (order) doSelect(order.id);
    }
  }

  /* ---------- 键盘 ---------- */

  function keyToken(event) {
    if (event.code && CODE_TOKENS[event.code]) return CODE_TOKENS[event.code];
    const key = event.key || '';
    return KEY_TOKENS[key.length === 1 ? key.toLowerCase() : key] || null;
  }

  function onButton(target) {
    return Boolean(target && target.closest && target.closest('button, a, input, select, textarea'));
  }

  function onKeyDown(event) {
    if (event.ctrlKey || event.metaKey || event.altKey) return;
    sfx.unlock();
    const token = keyToken(event);
    const scrolls = DIRECTIONS[token] || token === 'action';

    if (ui.sheets.length) {
      if (token === 'pause' && (event.key === 'Escape' || event.key === 'Esc' || event.code === 'Escape')) {
        event.preventDefault();
        if (!event.repeat) dismissTop();
      }
      return;
    }

    if (ui.screen === 'title') {
      if (scrolls && !onButton(event.target)) event.preventDefault();
      if (event.repeat) return;
      if (token === 'help') openHelp();
      else if (token === 'sound') toggleSound();
      return;
    }

    // 营业画面：方向键和空格不让页面滚动，长按产生的重复事件一律忽略。
    if (scrolls || token === 'pause') event.preventDefault();
    if (event.repeat || !token) return;
    if (token === 'pause') openPause();
    else if (token === 'help') openHelp();
    else if (token === 'sound') toggleSound();
    else runToken(token);
  }

  function onKeyUp(event) {
    // 空格松开时浏览器会“点击”当前聚焦的按钮；营业中空格只用来出锅和出餐。
    if (ui.screen === 'play' && !ui.sheets.length && keyToken(event) === 'action') event.preventDefault();
  }

  /* ---------- 鼠标与触屏 ---------- */

  // 按下即响应（不等松开）；键盘或读屏触发的 click（detail 为 0）也接住，同一次点按不会触发两回。
  function bindPress(node, handler) {
    node.addEventListener('pointerdown', (event) => {
      if (event.button > 0) return;
      sfx.unlock();
      handler(event);
    });
    node.addEventListener('click', (event) => {
      if (event.detail === 0) handler(event);
    });
  }

  function bindClick(node, handler) {
    node.addEventListener('click', () => {
      sfx.unlock();
      sfx.play('click');
      handler();
    });
  }

  /* ---------- 每帧把真实状态写到界面 ---------- */

  function makeTicket(order) {
    const recipe = RECIPES[order.recipeId];
    const li = document.createElement('li');
    li.className = 'ticket is-new';
    li.dataset.id = String(order.id);
    li.innerHTML =
      '<button type="button" class="ticket-btn">' +
        '<span class="ticket-head"><span class="ticket-key"></span><span class="ticket-name"></span></span>' +
        '<span class="ticket-price"></span>' +
        '<span class="ticket-seq" aria-hidden="true"></span>' +
        '<canvas class="ticket-dish" width="64" height="64" aria-hidden="true"></canvas>' +
        '<span class="ticket-wait"><span class="ticket-wait-bar"><span class="ticket-wait-fill"></span></span>' +
        '<span class="ticket-wait-text"></span></span>' +
        '<span class="ticket-stamp" aria-hidden="true">制作中</span>' +
      '</button>';
    li.querySelector('.ticket-name').textContent = recipe.name;
    li.querySelector('.ticket-price').textContent = recipe.price + ' 金币';
    li.querySelector('.ticket-seq').innerHTML = recipe.sequence.map((direction) =>
      '<i data-arrow="' + direction + '"><svg><use href="#i-arrow"/></svg></i>').join('');
    const canvas = li.querySelector('.ticket-dish');
    if (window.KitchenArt && canvas.getContext) window.KitchenArt.drawDish(canvas.getContext('2d'), recipe.id, 0, 0, 64);
    return {
      li: li, recipe: recipe, button: li.querySelector('.ticket-btn'), key: li.querySelector('.ticket-key'),
      fill: li.querySelector('.ticket-wait-fill'), text: li.querySelector('.ticket-wait-text'),
      index: -1, seconds: null, mood: '', selected: null
    };
  }

  function renderTickets() {
    const orders = state.orders;
    const orderKey = orders.map((order) => order.id).join(',');
    if (ui.shown.orderKey !== orderKey) {
      ui.shown.orderKey = orderKey;
      const alive = new Set();
      orders.forEach((order, index) => {
        let ticket = ticketEls.get(order.id);
        if (!ticket) {
          ticket = makeTicket(order);
          ticketEls.set(order.id, ticket);
        }
        alive.add(order.id);
        if (ticket.index !== index) {
          ticket.index = index;
          ticket.key.textContent = String(index + 1);
          ticket.button.setAttribute('aria-label',
            '订单 ' + (index + 1) + '：' + ticket.recipe.name + '，' + ticket.recipe.price + ' 金币');
        }
        el.tickets.appendChild(ticket.li); // 按当前顺序重新排好
      });
      ticketEls.forEach((ticket, id) => {
        if (alive.has(id)) return;
        ticket.li.remove();
        ticketEls.delete(id);
      });
    }
    orders.forEach((order) => {
      const ticket = ticketEls.get(order.id);
      if (!ticket) return;
      const selected = order.id === state.selectedId;
      if (ticket.selected !== selected) {
        ticket.selected = selected;
        ticket.li.classList.toggle('is-selected', selected);
        ticket.button.setAttribute('aria-pressed', String(selected));
      }
      if (state.practice) {
        if (ticket.seconds !== -1) {
          ticket.seconds = -1;
          ticket.text.textContent = '不限时';
          ticket.fill.style.transform = 'scaleX(1)';
        }
        return;
      }
      const ratio = order.maxPatience > 0 ? Math.max(0, Math.min(1, order.patience / order.maxPatience)) : 0;
      ticket.fill.style.transform = 'scaleX(' + ratio.toFixed(3) + ')';
      const seconds = Math.ceil(order.patience);
      if (ticket.seconds !== seconds) {
        ticket.seconds = seconds;
        ticket.text.textContent = seconds + ' 秒';
      }
      const mood = ratio < 0.25 ? 'urgent' : ratio < 0.5 ? 'tense' : 'calm';
      if (ticket.mood !== mood) {
        ticket.mood = mood;
        ticket.li.dataset.mood = mood;
      }
    });
  }

  // 订单夹下面的小纸条：今天出了几道、离下一颗星还差几道（星级规则见 backend-api.md）。
  function renderTally() {
    const key = (state.practice ? 'p' : 'd') + state.served;
    if (ui.shown.tally === key) return;
    ui.shown.tally = key;
    const served = state.served;
    const stars = served >= 10 ? 3 : served >= 5 ? 2 : served > 0 ? 1 : 0;
    el.tallyServed.textContent = String(served);
    Array.prototype.forEach.call(el.tallyStars.children, (star, index) => {
      star.classList.toggle('is-on', !state.practice && index < stars);
    });
    el.tallyStars.setAttribute('aria-label', state.practice ? '练习不计星' : '目前 ' + stars + ' 星');
    el.tallyNext.textContent = state.practice ? '练习不计星，慢慢练手。'
      : stars === 0 ? '出餐 1 道拿到第一颗星。'
        : stars === 1 ? '再出 ' + (5 - served) + ' 道升两星。'
          : stars === 2 ? '再出 ' + (10 - served) + ' 道升三星。'
            : '三星到手，继续冲分。';
  }

  function renderCue() {
    const sequenceKey = state.selectedId + ':' + state.sequence.join(',');
    let rebuilt = false;
    if (ui.shown.sequenceKey !== sequenceKey) {
      ui.shown.sequenceKey = sequenceKey;
      el.cueChop.innerHTML = state.sequence.map((direction) =>
        '<span class="tile" data-arrow="' + direction + '"><svg><use href="#i-arrow"/></svg></span>').join('');
      tiles = Array.prototype.slice.call(el.cueChop.children);
      rebuilt = true;
    }
    const progressKey = state.step + ':' + state.progress;
    if (rebuilt || ui.shown.progressKey !== progressKey) {
      ui.shown.progressKey = progressKey;
      tiles.forEach((tile, index) => {
        tile.classList.toggle('is-done', index < state.progress);
        tile.classList.toggle('is-next', state.step === 'chop' && index === state.progress);
      });
    }
    const heat = state.step === 'cook' || state.step === 'ready' ? state.heat : 0;
    const left = (heat * 100).toFixed(2) + '%';
    if (ui.shown.needle !== left) {
      ui.shown.needle = left;
      el.heatNeedle.style.left = left;
    }
  }

  function renderDom() {
    setData('phase', state.phase);
    setData('step', state.step);
    setData('pest', state.pest ? '1' : '0');
    if (ui.screen !== 'play') return;

    setText(el.hudDay, state.practice ? '练习' : '第 ' + state.day + ' 天', 'day');
    setText(el.hudTime, state.practice ? '∞' : String(Math.ceil(state.timeLeft)), 'time');
    setText(el.hudCoins, String(state.coins), 'coins');
    setText(el.hudScore, String(state.score), 'score');
    setText(el.hudCombo, '×' + state.combo, 'combo');
    if (el.hudTimeUnit.hidden !== state.practice) el.hudTimeUnit.hidden = state.practice;
    if (el.hudComboWrap.hidden !== state.combo < 2) el.hudComboWrap.hidden = state.combo < 2;
    const low = !state.practice && state.timeLeft <= 10 && state.phase === 'playing';
    if (ui.shown.low !== low) {
      ui.shown.low = low;
      el.hudTimeWrap.classList.toggle('is-low', low);
    }
    const label = state.practice ? '练习中，时间不限' : '剩余 ' + Math.ceil(state.timeLeft) + ' 秒';
    if (ui.shown.timeLabel !== label) {
      ui.shown.timeLabel = label;
      el.hudTimeWrap.setAttribute('aria-label', label);
    }

    setText(el.actionLabel, state.step === 'ready' ? '出餐' : '出锅', 'action');

    // feedback.id 变了才更新，读屏不会逐帧重读同一句话
    if (ui.shown.feedbackId !== state.feedback.id) {
      ui.shown.feedbackId = state.feedback.id;
      el.feedback.textContent = state.feedback.text;
      el.feedback.dataset.tone = state.feedback.tone;
      restartAnimation(el.feedback, 'is-fresh');
    }

    renderTickets();
    renderCue();
    renderTally();

    const pestOn = Boolean(state.pest) && (state.phase === 'playing' || state.phase === 'paused');
    if (el.pestBtn.hidden === pestOn) el.pestBtn.hidden = !pestOn;
    if (pestOn) el.pestFill.style.transform = 'scaleX(' + Math.max(0, Math.min(1, state.pest.remaining / 5)).toFixed(3) + ')';
  }

  // 标题画面里厨房画布是“铺满裁切”的，这里把木札和底栏的屏幕位置换算回画布坐标，
  // 告诉舞台猫厨师该站哪儿：右边够宽就站在柜台后面，不够就站到柜台上、木札下方。
  function titleLayout() {
    const box = el.stage.getBoundingClientRect();
    if (!box.width || !box.height) return null;
    const scale = Math.max(box.width / window.KitchenStage.WIDTH, box.height / window.KitchenStage.HEIGHT);
    const offsetX = box.left + (box.width - window.KitchenStage.WIDTH * scale) / 2;
    const offsetY = box.top + (box.height - window.KitchenStage.HEIGHT * scale) / 2;
    const tags = el.titleTags.getBoundingClientRect();
    const ledger = el.ledger.getBoundingClientRect();
    const room = box.right - tags.right;
    if (room >= 330 * scale) {
      const x = (tags.right + room / 2 - offsetX) / scale;
      return { behind: true, x: Math.min(window.KitchenStage.WIDTH - 200, x) };
    }
    const feet = Math.min(938, (ledger.top - offsetY) / scale - 8);
    const top = (tags.bottom - offsetY) / scale + 12;
    return {
      behind: false,
      x: (box.left + box.width / 2 - offsetX) / scale,
      feet: feet,
      scale: Math.max(1.3, Math.min(2.6, (feet - top) / 136))
    };
  }

  function measure() {
    const width = el.stage.clientWidth;
    if (width) el.stage.style.setProperty('--u', (width / 100).toFixed(3) + 'px');
    ui.titleLayout = ui.screen === 'title' ? titleLayout() : null;
  }

  function frame(now) {
    requestAnimationFrame(frame);
    advance(now);
    detect();
    renderDom();
    const cooking = ui.screen === 'play' && state.phase === 'playing' && state.step === 'cook';
    sfx.setSizzle(cooking ? 0.3 + state.heat * 0.7 : 0);
    stage.draw({
      mode: ui.screen === 'title' ? 'title' : 'play',
      step: state.phase === 'menu' ? 'select' : state.step,
      progress: state.progress,
      total: state.sequence.length,
      heat: state.heat,
      grade: state.grade,
      recipeId: selectedRecipeId(),
      paused: state.phase === 'paused',
      title: ui.titleLayout
    }, now);
  }

  /* ---------- 事件绑定 ---------- */

  document.addEventListener('keydown', onKeyDown);
  document.addEventListener('keyup', onKeyUp);
  window.addEventListener('blur', onAway);
  window.addEventListener('pagehide', onAway);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) onAway();
    ui.last = performance.now();
  });

  bindPress(el.pad, (event) => {
    const button = event.target.closest('button');
    if (!button) return;
    if (event.type === 'pointerdown') event.preventDefault();
    runToken(button.dataset.dir || button.dataset.act);
  });
  el.pad.addEventListener('contextmenu', (event) => event.preventDefault());

  bindPress(el.tickets, (event) => {
    const item = event.target.closest('.ticket');
    if (!item) return;
    if (event.type === 'pointerdown') event.preventDefault();
    doSelect(Number(item.dataset.id));
  });

  bindPress(el.pestBtn, (event) => {
    if (event.type === 'pointerdown') event.preventDefault();
    doShoo();
  });

  bindClick(el.btnStart, onStart);
  bindClick(el.btnPractice, () => begin(session.startPractice()));
  bindClick(el.btnHelp, openHelp);
  bindClick(el.btnSound, toggleSound);
  bindClick(el.btnReset, () => askConfirm(
    '清空三天的进度、钱包和升级，从第一天重新开始？最高分这些记录会留着。',
    '清空并重来',
    () => {
      const result = session.restartCampaign();
      if (result.ok) toast('进度已清空，从第一天开始。');
      else toastReason(result.reason);
      refreshTitle();
    }
  ));

  bindClick(el.btnPause, () => openPause());
  bindClick(el.btnHelpHud, openHelp);
  bindClick(el.btnSoundHud, toggleSound);

  bindClick(el.btnResume, resumeGame);
  bindClick(el.btnHelpPause, openHelp);
  bindClick(el.btnSoundPause, toggleSound);
  bindClick(el.btnRestartShift, () => {
    if (state.practice) { restartShift(); return; }
    askConfirm('今天从头再来？这一轮还没结算的收入会作废。', '重新开始今天', restartShift);
  });
  bindClick(el.btnLeave, () => {
    if (state.practice) { leaveShift(); return; }
    askConfirm('现在回到菜单，今天还没结算的收入会作废。', '回到菜单', leaveShift);
  });

  bindClick(el.btnHelpClose, closeHelp);
  bindClick(el.btnConfirmOk, () => answerConfirm(true));
  bindClick(el.btnConfirmCancel, () => answerConfirm(false));

  el.shopList.addEventListener('click', (event) => {
    const button = event.target.closest('button[data-key]');
    if (button && !button.disabled) buyUpgrade(button.dataset.key);
  });
  bindClick(el.btnNextDay, () => begin(session.nextDay()));
  bindClick(el.btnBillTitle, showTitle);
  bindClick(el.btnBillRestart, () => {
    const result = session.restartCampaign();
    if (!result.ok) { toastReason(result.reason); return; }
    begin(session.startDay());
  });

  if ('ResizeObserver' in window) new ResizeObserver(measure).observe(el.stage);
  window.addEventListener('resize', measure);
  if (motionQuery && motionQuery.addEventListener) {
    motionQuery.addEventListener('change', (event) => stage.setCalm(event.matches));
  }

  /* ---------- 启动 ---------- */

  sfx.setEnabled(session.profile.sound);
  drawTitleArt();
  showTitle();
  measure();
  // 存档里留着没处理完的结算：先把日结单摆出来。
  if (session.profile.summary) openBill(session.profile.summary);
  requestAnimationFrame(frame);

  // 联调与自动化测试用的只读入口：KitchenApp.session.snapshot()
  window.KitchenApp = { session: session };
})();
