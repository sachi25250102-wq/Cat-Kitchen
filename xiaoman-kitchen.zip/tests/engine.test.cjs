const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const enginePath = path.join(__dirname, '..', 'engine.js');
const KitchenEngine = fs.existsSync(enginePath) ? require(enginePath) : {};

function game(options = {}) {
  assert.equal(typeof KitchenEngine.createGame, 'function', 'createGame must be implemented');
  const result = KitchenEngine.createGame({ random: () => 0.5 });
  result.start(options);
  return result;
}

function chop(result, order = result.state.orders[0]) {
  result.selectOrder(order.id);
  for (const direction of result.state.sequence.slice()) result.input(direction);
  assert.equal(result.state.step, 'cook');
}

function ready(result) {
  chop(result);
  for (let index = 0; index < 100 && result.state.heat < 0.55; index += 1) result.tick(0.025);
  result.action();
  assert.equal(result.state.step, 'ready');
}

test('exposes the same classic-script engine in a browser with no require', () => {
  assert.ok(fs.existsSync(enginePath), 'engine.js must exist');
  const browser = {};
  vm.runInNewContext(fs.readFileSync(enginePath, 'utf8'), browser);
  assert.equal(typeof browser.KitchenEngine.createGame, 'function');
  assert.equal(browser.KitchenEngine.RECIPES.length, 3);
});

test('opens three playable first-day tickets and resets a new shift', () => {
  const result = game();
  assert.equal(result.state.phase, 'playing');
  assert.equal(result.state.timeLeft, 90);
  assert.equal(result.state.orders.length, 3);
  assert.ok(result.state.orders.some(order => order.recipeId === 'onigiri'));
  assert.ok(result.state.orders.every(order => ['onigiri', 'omurice'].includes(order.recipeId)));
  assert.equal(new Set(result.state.orders.map(order => order.id)).size, 3);
  ready(result);
  result.action();
  result.start({ day: 2 });
  assert.equal(result.state.score, 0);
  assert.equal(result.state.coins, 0);
  assert.equal(result.state.served, 0);
  assert.equal(result.state.step, 'select');
  assert.equal(result.state.selectedId, null);
});

test('completes a meal, pays once, records a perfect, and replaces its ticket', () => {
  const result = game();
  const ticket = result.state.orders[0].id;
  ready(result);
  assert.equal(result.state.grade, 'perfect');
  assert.equal(result.state.served, 0);
  result.action();
  assert.equal(result.state.served, 1);
  assert.equal(result.state.combo, 1);
  assert.equal(result.state.bestCombo, 1);
  assert.equal(result.state.stats.perfect, 1);
  assert.ok(result.state.coins > 0);
  assert.ok(result.state.score > 0);
  assert.equal(result.state.orders.length, 3);
  assert.ok(result.state.orders.every(order => order.id !== ticket));
  assert.equal(result.state.step, 'select');
  const coins = result.state.coins;
  result.action();
  result.action();
  assert.equal(result.state.served, 1);
  assert.equal(result.state.coins, coins);
});

test('wrong chopping resets the sequence and combo but allows the dish to finish', () => {
  const result = game();
  ready(result);
  result.action();
  result.selectOrder(result.state.orders[0].id);
  result.input(result.state.sequence[0]);
  result.input('invalid');
  assert.equal(result.state.progress, 1, 'unsupported inputs are ignored');
  const expected = result.state.sequence[1];
  result.input(expected === 'left' ? 'right' : 'left');
  assert.equal(result.state.progress, 0);
  assert.equal(result.state.combo, 0);
  for (const direction of result.state.sequence.slice()) result.input(direction);
  assert.equal(result.state.step, 'cook');
});

test('an early cooking action allows another try on the same cooking dish', () => {
  const result = game();
  chop(result);
  result.tick(0.1);
  const ticket = result.state.selectedId;
  result.action();
  assert.equal(result.state.step, 'cook');
  assert.equal(result.state.selectedId, ticket);
  assert.equal(result.state.combo, 0);
  while (result.state.heat < 0.5) result.tick(0.025);
  result.action();
  assert.equal(result.state.step, 'ready');
});

test('burned food resets preparation and can be remade on the same ticket', () => {
  const result = game();
  chop(result);
  const ticket = result.state.selectedId;
  result.tick(6);
  assert.equal(result.state.step, 'chop');
  assert.equal(result.state.selectedId, ticket);
  assert.equal(result.state.progress, 0);
  assert.equal(result.state.heat, 0);
  assert.equal(result.state.stats.burned, 1);
  assert.equal(result.state.served, 0);
  for (const direction of result.state.sequence.slice()) result.input(direction);
  assert.equal(result.state.step, 'cook');
});

test('switching tickets resets prep and switching during cooking is blocked', () => {
  const result = game();
  const [first, second] = result.state.orders;
  result.selectOrder(first.id);
  result.input(result.state.sequence[0]);
  result.selectOrder(first.id);
  assert.equal(result.state.progress, 1, 'reselecting preserves progress');
  result.selectOrder(second.id);
  assert.equal(result.state.selectedId, second.id);
  assert.equal(result.state.progress, 0);
  assert.notDeepEqual(result.state.sequence, []);
  for (const direction of result.state.sequence.slice()) result.input(direction);
  result.selectOrder(first.id);
  assert.equal(result.state.selectedId, second.id);
  assert.equal(result.state.step, 'cook');
});

test('a selected ticket expiring clears every prep stage and leaves other tickets playable', () => {
  for (const step of ['chop', 'cook', 'ready']) {
    const result = game();
    if (step === 'ready') ready(result);
    else if (step === 'cook') chop(result);
    else result.selectOrder(result.state.orders[0].id);
    const selected = result.state.orders.find(order => order.id === result.state.selectedId);
    selected.patience = 0.1;
    result.tick(0.2);
    assert.equal(result.state.missed, 1, step);
    assert.equal(result.state.selectedId, null, step);
    assert.equal(result.state.step, 'select', step);
    assert.equal(result.state.orders.length, 3, step);
    chop(result);
  }
});

test('an unrelated expiring ticket does not interrupt the selected preparation', () => {
  const result = game();
  result.selectOrder(result.state.orders[0].id);
  result.input(result.state.sequence[0]);
  const selected = result.state.selectedId;
  result.state.orders[1].patience = 0.1;
  result.tick(0.2);
  assert.equal(result.state.selectedId, selected);
  assert.equal(result.state.progress, 1);
  assert.equal(result.state.missed, 1);
});

test('pause freezes clock, cooking, tickets, pest, and all actions', () => {
  const result = game();
  result.tick(16.1);
  assert.ok(result.state.pest);
  chop(result);
  result.pause();
  const snapshot = JSON.stringify(result.state);
  result.tick(20);
  result.action();
  result.input('up');
  result.selectOrder(result.state.orders[1].id);
  result.shoo();
  assert.equal(JSON.stringify(result.state), snapshot);
  result.resume();
  result.tick(0.2);
  assert.equal(result.state.phase, 'playing');
  assert.ok(result.state.heat > 0);
  assert.ok(result.state.pest.remaining < 4.9);
});

test('a pest appears after its delay and shooing it rewards only once', () => {
  const result = game();
  result.tick(11.9);
  assert.equal(result.state.pest, null);
  result.tick(8.1);
  assert.ok(result.state.pest);
  assert.ok(result.state.pest.remaining > 0 && result.state.pest.remaining <= 5);
  result.shoo();
  assert.equal(result.state.pest, null);
  assert.equal(result.state.stats.pests, 1);
  const coins = result.state.coins;
  assert.ok(coins > 0);
  result.shoo();
  assert.equal(result.state.coins, coins);
});

test('an unattended pest leaves and takes additional patience from waiting orders', () => {
  const result = game();
  result.tick(16.1);
  assert.ok(result.state.pest);
  const first = result.state.orders[0];
  const before = first.patience;
  result.tick(5);
  assert.equal(result.state.pest, null);
  assert.ok(first.patience < before - 5);
  assert.equal(result.state.stats.pests, 0);
});

test('practice has endless time, patience, and no pests while meals remain playable', () => {
  const result = game({ practice: true });
  const before = result.state.orders.map(order => order.patience);
  const time = result.state.timeLeft;
  result.tick(1000);
  assert.equal(result.state.phase, 'playing');
  assert.equal(result.state.timeLeft, time);
  assert.deepEqual(result.state.orders.map(order => order.patience), before);
  assert.equal(result.state.pest, null);
  assert.equal(result.state.missed, 0);
  ready(result);
  result.action();
  assert.equal(result.state.served, 1);
});

test('a shift ends at 90 seconds and every gameplay action then freezes', () => {
  const result = game();
  result.tick(89.75);
  assert.equal(result.state.phase, 'playing');
  result.tick(5);
  assert.equal(result.state.phase, 'summary');
  assert.equal(result.state.timeLeft, 0);
  const snapshot = JSON.stringify(result.state);
  result.tick(100);
  result.selectOrder(result.state.orders[0].id);
  result.input('up');
  result.action();
  result.shoo();
  result.pause();
  result.resume();
  assert.equal(JSON.stringify(result.state), snapshot);
});

test('upgrades are bounded, extend patience, slow heat, and increase served payout', () => {
  const base = game();
  const upgraded = game({ upgrades: { stove: 99, patience: 2.9, charm: 3, extra: 50 } });
  assert.deepEqual(upgraded.state.upgrades, { stove: 3, patience: 2, charm: 3 });
  assert.ok(upgraded.state.orders[0].maxPatience > base.state.orders[0].maxPatience);
  chop(base);
  chop(upgraded);
  base.tick(0.5);
  upgraded.tick(0.5);
  assert.ok(upgraded.state.heat < base.state.heat);
  while (base.state.heat < 0.55) base.tick(0.025);
  while (upgraded.state.heat < 0.55) upgraded.tick(0.025);
  base.action();
  upgraded.action();
  base.action();
  upgraded.action();
  assert.ok(upgraded.state.coins > base.state.coins);
  const invalid = game({ day: 99, upgrades: { stove: -2, patience: 'bad', charm: Infinity } });
  assert.equal(invalid.state.day, 3);
  assert.deepEqual(invalid.state.upgrades, { stove: 0, patience: 0, charm: 0 });
});

test('curry unlocks on day two and three successive shifts can settle and restart', () => {
  assert.equal(typeof KitchenEngine.createGame, 'function', 'createGame must be implemented');
  for (const day of [1, 2, 3]) {
    const result = KitchenEngine.createGame({ random: () => 0.999 });
    result.start({ day });
    if (day === 1) assert.ok(result.state.orders.every(order => order.recipeId !== 'curry'));
    else assert.ok(result.state.orders.some(order => order.recipeId === 'curry'));
    ready(result);
    result.action();
    result.tick(90);
    assert.equal(result.state.phase, 'summary');
    assert.equal(result.state.served, 1);
    result.start({ day });
    assert.equal(result.state.phase, 'playing');
    assert.equal(result.state.timeLeft, 90);
    assert.equal(result.state.served, 0);
  }
});

test('invalid elapsed time and stale ticket ids leave active preparation intact', () => {
  const result = game();
  result.selectOrder(result.state.orders[0].id);
  result.input(result.state.sequence[0]);
  const snapshot = JSON.stringify(result.state);
  for (const seconds of [NaN, Infinity, -1, 0, '5']) result.tick(seconds);
  result.selectOrder('missing-ticket');
  assert.equal(JSON.stringify(result.state), snapshot);
});

test('quit returns every phase to menu, clears active prep, and freezes until restart', () => {
  for (const phase of ['playing', 'paused', 'summary', 'menu']) {
    const result = game({ practice: phase === 'paused' });
    assert.equal(typeof result.quit, 'function', 'quit must be implemented');
    chop(result);
    result.tick(0.5);
    if (!result.state.practice) result.tick(15.6);
    if (phase === 'paused') result.pause();
    if (phase === 'summary') result.tick(90);
    if (phase === 'menu') result.quit();
    result.quit();
    assert.equal(result.state.phase, 'menu', phase);
    assert.equal(result.state.selectedId, null, phase);
    assert.equal(result.state.step, 'select', phase);
    assert.deepEqual(result.state.sequence, [], phase);
    assert.equal(result.state.progress, 0, phase);
    assert.equal(result.state.heat, 0, phase);
    assert.equal(result.state.grade, null, phase);
    assert.equal(result.state.pest, null, phase);
    const snapshot = JSON.stringify(result.state);
    result.quit();
    result.tick(100);
    result.selectOrder(result.state.orders[0].id);
    result.input('up');
    result.action();
    result.shoo();
    result.pause();
    result.resume();
    assert.equal(JSON.stringify(result.state), snapshot, phase);
    result.start();
    chop(result);
    result.tick(0.5);
    assert.equal(result.state.phase, 'playing', phase);
    assert.ok(result.state.heat > 0, phase);
  }
});
