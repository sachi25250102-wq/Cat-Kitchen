# 小满食堂

原创中文离线单机烹饪游戏。樱花巷口的小食堂，猫厨师接单、切菜、控火、出餐，把小店开满三天。

## 怎么玩

双击 `index.html`，用 Chrome 或 Edge 打开即可。不需要联网、安装或服务器。

| 操作 | 键盘 | 鼠标、触屏 |
| --- | --- | --- |
| 选单 | `1` `2` `3` | 点右侧订单 |
| 切菜 | 方向键或 `W` `A` `S` `D` | 点方向按钮 |
| 出锅、出餐 | 空格 | 点“出锅 / 出餐” |
| 赶走小馋鬼 | `F` | 点它，或点“赶走” |
| 暂停 | `Esc` 或 `P` | 右上角暂停按钮 |
| 帮助、声音 | `H`、`M` | 右上角按钮 |

每天营业 90 秒，共三天。打烊后用当天赚的金币添置升级。练习模式不计时，也不记收入。切到别的窗口会自动暂停，回来后手动继续。

进度保存在浏览器本地存储里。浏览器不允许本地存储时游戏照常可玩，只是关掉页面后进度不保留。

## 文件

| 文件 | 作用 | 负责 |
| --- | --- | --- |
| `index.html`、`style.css` | 页面结构与样式 | Claude |
| `game.js` | 前端主控：输入、帧循环、弹层、结算界面 | Claude |
| `stage.js` | Canvas 厨房舞台和动效 | Claude |
| `sfx.js` | Web Audio 合成音效 | Claude |
| `e2e/smoke.cjs` | 浏览器冒烟测试 | Claude |
| `engine.js` | 游戏规则状态机 | Codex |
| `session.js` | 钱包、升级、三天进度、存档 | Codex |
| `tests/*.test.cjs` | 后端单元测试 | Codex |
| `art.js`、`assets/kitchen.png` | 角色与菜品绘制、厨房背景 | Codex |

接口约定见 `docs/backend-api.md`，协作状态见 `docs/coordination/`。

## 测试

游戏本身没有任何依赖。测试需要 Node 18 以上。

```powershell
npm test          # 后端单元测试
npm run check     # 六个脚本的语法检查

npm install --no-save playwright-core
npm run e2e       # 真实浏览器冒烟测试，用本机的 Edge 或 Chrome
```

冒烟测试可选的环境变量：`BROWSER_CHANNEL`（`msedge` 或 `chrome`）、`CHROME_PATH`（浏览器可执行文件路径）、`SHOTS`（截图输出目录）。
