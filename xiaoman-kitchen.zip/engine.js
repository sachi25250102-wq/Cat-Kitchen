(function (root, factory) {
  'use strict';
  const engine = factory();
  if (typeof module === 'object' && module.exports) module.exports = engine;
  root.KitchenEngine = engine;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const RECIPES = Object.freeze([
    Object.freeze({ id: 'onigiri', name: '梅子饭团', price: 14, sequence: Object.freeze(['up', 'right', 'down']), color: '#e7e4c9' }),
    Object.freeze({ id: 'omurice', name: '番茄蛋包饭', price: 22, sequence: Object.freeze(['left', 'up', 'right', 'down']), color: '#f1ba67' }),
    Object.freeze({ id: 'curry', name: '金黄咖喱饭', price: 30, sequence: Object.freeze(['up', 'left', 'down', 'right', 'up']), color: '#c78b46' })
  ]);
  const DIRECTIONS = new Set(['up', 'down', 'left', 'right']);
  const EPSILON = 0.000001;

  function boundedInteger(value, minimum, maximum, fallback) {
    return Number.isFinite(value) ? Math.max(minimum, Math.min(maximum, Math.floor(value))) : fallback;
  }

  function createGame(options = {}) {
    const random = typeof options.random === 'function' ? options.random : Math.random;
    let ticketId = 0;
    let feedbackId = 0;
    let pestClock = 16;
    const state = {
      phase: 'menu', day: 1, practice: false, timeLeft: 90,
      coins: 0, score: 0, served: 0, missed: 0, combo: 0, bestCombo: 0,
      orders: [], selectedId: null, step: 'select', sequence: [], progress: 0,
      heat: 0, grade: null, pest: null,
      feedback: { text: '欢迎来到小满食堂', tone: 'info', id: 0 },
      stats: { perfect: 0, burned: 0, pests: 0 },
      upgrades: { stove: 0, patience: 0, charm: 0 }
    };

    function roll() {
      const value = random();
      return Number.isFinite(value) ? Math.max(0, Math.min(0.999999, value)) : 0.5;
    }

    function feedback(text, tone = 'info') {
      state.feedback = { text, tone, id: ++feedbackId };
    }

    function recipeFor(order) {
      return RECIPES.find(recipe => recipe.id === order.recipeId);
    }

    function selectedOrder() {
      return state.orders.find(order => order.id === state.selectedId);
    }

    function clearPrep() {
      state.selectedId = null;
      state.step = 'select';
      state.sequence = [];
      state.progress = 0;
      state.heat = 0;
      state.grade = null;
    }

    function resetChop() {
      state.step = 'chop';
      state.progress = 0;
      state.heat = 0;
      state.grade = null;
    }

    function addOrder(recipe) {
      const pool = state.day === 1 ? RECIPES.slice(0, 2) : RECIPES;
      const chosen = recipe || pool[Math.floor(roll() * pool.length)];
      const maxPatience = 38 - (state.day - 1) * 4 + state.upgrades.patience * 6;
      state.orders.push({ id: ++ticketId, recipeId: chosen.id, patience: maxPatience, maxPatience });
    }

    function restock() {
      while (state.orders.length < 3) addOrder();
    }

    function start({ day = 1, practice = false, upgrades = {} } = {}) {
      const safeUpgrades = upgrades && typeof upgrades === 'object' ? upgrades : {};
      Object.assign(state, {
        phase: 'playing', day: boundedInteger(day, 1, 3, 1), practice: Boolean(practice), timeLeft: 90,
        coins: 0, score: 0, served: 0, missed: 0, combo: 0, bestCombo: 0,
        orders: [], pest: null, stats: { perfect: 0, burned: 0, pests: 0 },
        upgrades: {
          stove: boundedInteger(safeUpgrades.stove, 0, 3, 0),
          patience: boundedInteger(safeUpgrades.patience, 0, 3, 0),
          charm: boundedInteger(safeUpgrades.charm, 0, 3, 0)
        }
      });
      clearPrep();
      addOrder(RECIPES[0]);
      addOrder(RECIPES[1]);
      restock();
      pestClock = 12 + roll() * 8;
      feedback(state.practice ? '慢慢来，先选一张订单练练手。' : `第 ${state.day} 天开店！先选一张订单吧。`);
      return state;
    }

    function selectOrder(id) {
      if (state.phase !== 'playing') return;
      const order = state.orders.find(ticket => ticket.id === id);
      if (!order || state.selectedId === id) return;
      if (state.step === 'cook') {
        feedback('锅里还有料理，先照看好火候。', 'warning');
        return;
      }
      state.selectedId = order.id;
      state.sequence = recipeFor(order).sequence.slice();
      resetChop();
      feedback(`${recipeFor(order).name}：照着方向切菜吧。`);
    }

    function input(direction) {
      if (state.phase !== 'playing' || state.step !== 'chop' || !DIRECTIONS.has(direction)) return;
      if (direction !== state.sequence[state.progress]) {
        state.progress = 0;
        state.combo = 0;
        state.score = Math.max(0, state.score - 5);
        feedback('切错啦，从第一个方向重新来。', 'error');
        return;
      }
      state.progress += 1;
      if (state.progress === state.sequence.length) {
        state.step = 'cook';
        state.heat = 0;
        feedback('食材下锅！指针进入绿色时按空格。', 'success');
      } else feedback('咚！切得不错。', 'success');
    }

    function action() {
      if (state.phase !== 'playing') return;
      const order = selectedOrder();
      if (!order) {
        feedback('先点一张订单，或按 1、2、3 选单。');
        return;
      }
      if (state.step === 'cook') {
        if (state.heat >= 0.42 && state.heat <= 0.72) {
          state.grade = state.heat >= 0.52 && state.heat <= 0.62 ? 'perfect' : 'good';
          state.step = 'ready';
          feedback(state.grade === 'perfect' ? '完美火候！再按空格出餐。' : '香喷喷出锅！再按空格出餐。', 'success');
        } else {
          state.combo = 0;
          state.score = Math.max(0, state.score - 8);
          feedback(state.heat < 0.42 ? '还没熟，等指针进入绿色再试一次。' : '火有点大了，要在绿色区间出锅哦。', 'warning');
        }
        return;
      }
      if (state.step !== 'ready') return;
      const recipe = recipeFor(order);
      state.combo += 1;
      state.bestCombo = Math.max(state.bestCombo, state.combo);
      const perfect = state.grade === 'perfect';
      const tip = (perfect ? 4 : 0) + Math.min(5, state.combo - 1) + state.upgrades.charm * 2;
      state.coins += recipe.price + tip;
      state.score += (perfect ? 150 : 100) + Math.min(10, state.combo - 1) * 15;
      state.served += 1;
      if (perfect) state.stats.perfect += 1;
      state.orders = state.orders.filter(ticket => ticket.id !== order.id);
      clearPrep();
      restock();
      feedback(`${recipe.name}送到了！+${recipe.price + tip} 金币`, 'success');
    }

    function shoo() {
      if (state.phase !== 'playing' || !state.pest) return;
      state.pest = null;
      state.stats.pests += 1;
      state.coins += 2;
      state.score += 10;
      feedback('小馋鬼跑走啦！+2 金币', 'success');
    }

    function expireOrders() {
      const expired = state.orders.filter(order => order.patience <= EPSILON);
      if (!expired.length) return;
      state.missed += expired.length;
      state.combo = 0;
      state.score = Math.max(0, state.score - expired.length * 25);
      if (expired.some(order => order.id === state.selectedId)) clearPrep();
      state.orders = state.orders.filter(order => order.patience > EPSILON);
      restock();
      feedback('有客人等不及离开了，新订单已经送到。', 'warning');
    }

    function heatDuration() {
      return 2.8 + state.upgrades.stove * 0.45;
    }

    function burn() {
      state.stats.burned += 1;
      state.combo = 0;
      state.score = Math.max(0, state.score - 15);
      resetChop();
      feedback('哎呀，糊锅了！这道菜重新切菜就好。', 'error');
    }

    function tick(seconds) {
      if (state.phase !== 'playing' || !Number.isFinite(seconds) || seconds <= 0) return;
      if (state.practice) {
        if (state.step === 'cook') {
          state.heat = Math.min(1, state.heat + seconds / heatDuration());
          if (state.heat >= 1 - EPSILON) burn();
        }
        return;
      }
      let remaining = Math.min(seconds, state.timeLeft);
      // Advance to event boundaries so large ticks behave like small animation frames.
      while (remaining > EPSILON && state.phase === 'playing') {
        let delta = Math.min(remaining, state.timeLeft, pestClock);
        for (const order of state.orders) delta = Math.min(delta, Math.max(0, order.patience));
        if (state.pest) delta = Math.min(delta, Math.max(0, state.pest.remaining));
        if (state.step === 'cook') delta = Math.min(delta, Math.max(0, (1 - state.heat) * heatDuration()));

        state.timeLeft = Math.max(0, state.timeLeft - delta);
        remaining = Math.max(0, remaining - delta);
        pestClock -= delta;
        for (const order of state.orders) order.patience = Math.max(0, order.patience - delta);
        if (state.pest) state.pest.remaining = Math.max(0, state.pest.remaining - delta);
        if (state.step === 'cook') state.heat = Math.min(1, state.heat + delta / heatDuration());

        if (state.timeLeft <= EPSILON) {
          state.timeLeft = 0;
          state.phase = 'summary';
          state.pest = null;
          feedback('今天辛苦啦！看看小店的营业成果吧。', 'success');
          break;
        }
        if (state.pest && state.pest.remaining <= EPSILON) {
          state.pest = null;
          for (const order of state.orders) order.patience = Math.max(0, order.patience - 8);
          state.combo = 0;
          feedback('小馋鬼偷吃了一口，客人有点着急了。', 'warning');
        }
        expireOrders();
        if (state.step === 'cook' && state.heat >= 1 - EPSILON) burn();
        if (pestClock <= EPSILON) {
          state.pest = { remaining: 5, kind: roll() < 0.5 ? 'sparrow' : 'tanuki' };
          pestClock = 12 + roll() * 8;
          feedback('小馋鬼来了！按 F 或点它，赶快保护食材。', 'warning');
        }
      }
    }

    function pause() {
      if (state.phase !== 'playing') return;
      state.phase = 'paused';
    }

    function resume() {
      if (state.phase !== 'paused') return;
      state.phase = 'playing';
    }

    function quit() {
      state.phase = 'menu';
      state.pest = null;
      clearPrep();
    }

    return { state, start, selectOrder, input, action, shoo, tick, pause, resume, quit };
  }

  return { RECIPES, createGame };
});
